<!DOCTYPE html>
<html lang="en">
    <?php 
        $title = "Home";
        require_once("./include/header.inc.php");
    ?>
    <main>
        <!-- slideshow content begin -->
        <div  class="uk-section uk-padding-remove-vertical in-slideshow-gradient">
            <div id="particles-js" class="uk-light in-slideshow uk-background-contain" data-src="assets/img/in-equity-14-bg.svg" data-uk-img data-uk-slideshow>
                <hr>
                <ul class="uk-slideshow-items">
                    <li class="uk-flex uk-flex-middle">
                        <div class="uk-container">
                            <div class="uk-grid-large uk-flex-middle" data-uk-grid>
                                <div class="uk-width-1-2@s in-slide-text">
                                    <!-- <p class="in-badge-text uk-text-small uk-margin-remove-bottom uk-visible@m"><span class="uk-label uk-label-success in-label-small">New</span>Tradeing platforms.</p> -->
                                    <h1 class="uk-heading-small uk-text-uppercase uk-text-bold">Your trust for a stable investment.</h1>
                                    <!-- <h1 class="uk-heading-small">Your number cryptocurrency trading platform that's trusted on <span class="in-highlight">stable investment</span>.</h1> -->
                                    <p class="uk-text-lead uk-visible@m">
                                        ULTRAELON is an African based international financial company engaged in investment
                                        activities, which are related to trading on financial markets and cryptocurrency exchanges
                                        performed by qualified professional traders.
                                    </p>
                                        <!-- Get the most accurate market data, alerts, conversions, tools and more — all within the same app.</p> -->
                                    <div class="uk-grid-medium uk-child-width-auto uk-margin-medium-top uk-visible@s" data-uk-grid data-market="TSLA,GOOGL,AAPL">
                                        <div>
                                            <a href="./register.php" class="uk-card uk-card-small uk-card-secondary uk-card-body uk-border-rounded uk-flex">
                                                <h3 class="uk-text-default">Create an account <i class="fas fa-arrow-circle-right uk-margin-small-left"></i></h3>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="in-slide-img">
                                    <img src="assets/img/in-lazy.gif" data-src="assets/header-06.png" alt="image-slide" data-uk-img>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="uk-container">
                    <div class="uk-position-relative" data-uk-grid>
                        <ul class="uk-slideshow-nav uk-dotnav uk-position-bottom-right uk-flex uk-flex-middle"></ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- slideshow content end -->
        <!-- section content begin -->
        <div class="uk-section in-equity-7 uk-background-contain uk-background-top-left" data-src="assets/img/in-equity-7-bg.jpg" data-uk-img>
            <div class="uk-container uk-margin-medium-top uk-margin-bottom">
                <div class="uk-grid">
                    <div class="uk-width-1-2@m in-symbol-wrap">
                        <div class="uk-inline uk-dark uk-width-1-1 uk-height-1-1">
                            <span class="uk-position-absolute uk-transform-center in-symbol-1" style="left: 12%; top: 42%">
                                <img src="./v1/assets/icons/bitcoin.svg" alt="symbol-logo">
                            </span>
                            <span class="uk-position-absolute uk-transform-center in-symbol-2" style="left: 58%; top: 18%">
                                <img src="./v1/assets/icons/eth.svg" alt="symbol-logo">
                            </span>
                            <span class="uk-position-absolute uk-transform-center in-symbol-3" style="left: 22%; top: 13%">
                                <img src="./v1/assets/icons/bnb.svg" alt="symbol-logo">
                            </span>
                            <span class="uk-position-absolute uk-transform-center in-symbol-4" style="left: 70%; top: 60%">
                                <img src="./v1/assets/icons/usdt.svg" alt="symbol-logo">
                            </span>
                            <span class="uk-position-absolute uk-transform-center in-symbol-5" style="left: 10%; top: 38%"></span>
                            <span class="uk-position-absolute uk-transform-center in-symbol-6" style="left: 52%; top: 6%"></span>
                            <span class="uk-position-absolute uk-transform-center in-symbol-7" style="left: 70%; top: 89%"></span>
                            <span class="uk-position-absolute uk-transform-center in-symbol-8" style="left: 32%; top: 97%"></span>
                        </div>
                    </div>
                    <div class="uk-width-1-2@m uk-margin-bottom">
                        <a href="./about.php" class="uk-label">Read about us<i class="fas fa-arrow-right fa-xs uk-margin-small-left"></i></a>
                        <h1 class="uk-margin-top">Trade with <span class="in-highlight">confidence</span></h1>
                        <p class="uk-text-lead uk-margin-top">
                        UltraElon investment plans have a high daily return on investment. Our fund is managed by experienced professionals from around the world, and we invest in lucrative markets such as Gold, oil, and forex, bonds, stock exchange and crypto.</p>
                        <div class="uk-grid-medium uk-child-width-1-2@m uk-child-width-1-2@s uk-margin-medium-top" data-uk-grid>
                            <div>
                                <div class="uk-card uk-card-default uk-card-body uk-border-rounded uk-box-shadow-medium uk-text-center">
                                    <img class="uk-align-center" src="assets/img/in-lazy.gif" data-src="assets/img/in-equity-7-icon-1.svg" alt="icon-1" data-width data-height data-uk-img>
                                    <h4 class="uk-margin-remove">First Goal</h4>
                                    <p class="uk-margin-small-top uk-margin-small-bottom">
                                    In association with the ultra-token platform; How goal is to make trading, profitable for newbies and the long term traders.
                                    </p>
                                </div>
                            </div>
                            <div>
                                <div class="uk-card uk-card-default uk-card-body uk-border-rounded uk-box-shadow-medium uk-text-center">
                                    <img class="uk-align-center" src="assets/img/in-lazy.gif" data-src="assets/img/in-equity-7-icon-2.svg" alt="icon-2" data-width data-height data-uk-img>
                                    <h4 class="uk-margin-remove">Second Goal</h4>
                                    <p class="uk-margin-small-top uk-margin-small-bottom">
                                        <!-- One of our most adhered goal is  -->
                                        To see that our investors gain quick and instant access to their funds; using our automated blockchain payment system.
                                    </p>
                                    <!-- <a href="#" class="uk-button uk-button-text uk-margin-top uk-margin-small-bottom">Learn more<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section content end -->
        <!-- section content begin -->
        <!-- See Accounts Investment Plans -->
        <!-- <div class="uk-section in-equity-17">
            <div class="uk-container uk-margin-top uk-margin-medium-bottom">
                <div class="uk-grid uk-grid-collapsed uk-flex uk-flex-center">
                    <div class="uk-width-3-5@m uk-text-center">
                        <h1 class="uk-margin-remove">Choose your <span class="in-highlight">Investmen</span> plan</h1>
                        <p class="uk-text-lead uk-text-muted uk-margin-small-top">Simply select your preferred investment plan and grow your account.</p>
                    </div>
                    <div class="uk-width-1-1 uk-margin-medium-top">
                        <div class="uk-grid-small uk-child-width-1-2@s  uk-child-width-1-3@l in-equity-pricing" data-uk-grid>
                            
                            <div>
                                <div class="uk-card uk-card-default uk-card-body uk-box-shadow-medium">
                                    <p class="uk-text-small uk-text-muted uk-text-uppercase">Minimum funding<span class="uk-label uk-margin-small-left in-label-small">USD 200</span></p>
                                    <h2 class="uk-margin-top uk-margin-remove-bottom">Classic account</h2>
                                    <p class="uk-text-lead uk-text-muted uk-margin-remove-top">Benefit from industry-leading entry prices</p>
                                    <hr>
                                    <ul class="uk-list uk-list-bullet in-list-check">
                                        <li>One of the established industry leaders</li>
                                        <li>Three decades of trading know-how</li>
                                        <li>Award-winning customer service*</li>
                                        <li>Highly-regarded trader education*</li>
                                        <li>Advanced risk management</li>
                                        <li>Tax-free spread betting profits</li>
                                        <li>Low minimum deposit</li>
                                    </ul>
                                    <a href="#" class="uk-button uk-button-primary uk-border-rounded uk-align-center">Open an account<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="uk-card uk-card-default uk-card-body uk-box-shadow-large">
                                    <p class="uk-text-small uk-text-muted uk-text-uppercase">Minimum funding<span class="uk-label uk-margin-small-left in-label-small">USD 500</span></p>
                                    <h2 class="uk-margin-top uk-margin-remove-bottom">Platinum account</h2>
                                    <p class="uk-text-lead uk-text-muted uk-margin-remove-top">Receive even tighter spreads and commissions</p>
                                    <hr>
                                    <ul class="uk-list uk-list-bullet in-list-check">
                                        <li>Award-winning trading platform*</li>
                                        <li>Wide range of charting tools</li>
                                        <li>Fast, automated excecution</li>
                                        <li>Expert news & analysis</li>
                                        <li>Competitive spreads</li>
                                        <li>Advanced trading tools</li>
                                        <li>Tax-free spread betting profits</li>
                                    </ul>
                                    <a href="#" class="uk-button uk-button-primary uk-border-rounded uk-align-center">Open an account<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="uk-card uk-card-default uk-card-body uk-box-shadow-large">
                                    <p class="uk-text-small uk-text-muted uk-text-uppercase">Minimum funding<span class="uk-label uk-margin-small-left in-label-small">USD 500</span></p>
                                    <h2 class="uk-margin-top uk-margin-remove-bottom">Platinum account</h2>
                                    <p class="uk-text-lead uk-text-muted uk-margin-remove-top">Receive even tighter spreads and commissions</p>
                                    <hr>
                                    <ul class="uk-list uk-list-bullet in-list-check">
                                        <li>Award-winning trading platform*</li>
                                        <li>Wide range of charting tools</li>
                                        <li>Fast, automated excecution</li>
                                        <li>Expert news & analysis</li>
                                        <li>Competitive spreads</li>
                                        <li>Advanced trading tools</li>
                                        <li>Tax-free spread betting profits</li>
                                    </ul>
                                    <a href="#" class="uk-button uk-button-primary uk-border-rounded uk-align-center">Open an account<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="uk-card uk-card-default uk-card-body uk-box-shadow-medium">
                                    <p class="uk-text-small uk-text-muted uk-text-uppercase">Minimum funding<span class="uk-label uk-margin-small-left in-label-small">USD 200</span></p>
                                    <h2 class="uk-margin-top uk-margin-remove-bottom">Classic account</h2>
                                    <p class="uk-text-lead uk-text-muted uk-margin-remove-top">Benefit from industry-leading entry prices</p>
                                    <hr>
                                    <ul class="uk-list uk-list-bullet in-list-check">
                                        <li>One of the established industry leaders</li>
                                        <li>Three decades of trading know-how</li>
                                        <li>Award-winning customer service*</li>
                                        <li>Highly-regarded trader education*</li>
                                        <li>Advanced risk management</li>
                                        <li>Tax-free spread betting profits</li>
                                        <li>Low minimum deposit</li>
                                    </ul>
                                    <a href="#" class="uk-button uk-button-default uk-border-rounded uk-align-center">Open an account<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->




        <div class="uk-section in-equity-17">
            <div class="uk-container uk-margin-top uk-margin-medium-bottom">
                <div class="uk-grid uk-flex uk-flex-center">
                    <div class="uk-width-3-5@m uk-text-center">
                        <h1 class="uk-margin-remove">Choose your <span class="in-highlight">Investment</span> plan</h1>
                        <p class="uk-text-lead uk-text-muted uk-margin-small-top">Simply select your preferred investment plan and grow your account.</p>
                    </div>
                    <div class="uk-width-3-4@m uk-margin-medium-top">
                        <div class="uk-grid-collapse uk-child-width-1-2@m in-equity-pricing uk-grid" data-uk-grid="">
                            <div class="uk-first-column">
                                <div class="uk-card uk-card-default uk-card-body uk-box-shadow-medium">
                                    <p class="uk-text-small uk-text-muted uk-text-uppercase">Minimum funding<span class="uk-label uk-margin-small-left in-label-small">USD 5</span></p>
                                    <h2 class="uk-margin-top uk-margin-remove-bottom">Classic Plan</h2>
                                    <!-- <p class="uk-text-lead uk-text-muted uk-margin-remove-top">Benefit from industry-leading entry prices</p> -->
                                    <hr>
                                    <ul class="uk-list uk-list-bullet in-list-check">
                                        <li>Instant Withdrawal</li>
                                        <li>Minimum Capital: <span class="in-highText">$5</span> </li>
                                        <li>Maximum Capital: <span class="in-highText">$500</span> </li>
                                        <li>Duration: <span class="in-highText">24Hours.</span></li>
                                        <li>Profit: <span class="in-highText">8% ROI</span></li>
                                        <li>Plus: <span class="in-highText">2% Ultra token</span></li>
                                        <li>Referral Bonus: <span class="in-highText">3% of deposit </span></li>
                                    </ul>
                                    <a href="#" class="uk-button uk-button-default uk-border-rounded uk-align-center">Invest on Classic Plan<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="uk-card uk-card-default uk-card-body uk-box-shadow-large">
                                    <p class="uk-text-small uk-text-muted uk-text-uppercase">Minimium funding<span class="uk-label uk-margin-small-left in-label-small">USD 500</span></p>
                                    <h2 class="uk-margin-top uk-margin-remove-bottom">Premium Plan</h2>
                                    <!-- <p class="uk-text-lead uk-text-muted uk-margin-remove-top">Receive even tighter spreads and commissions</p> -->
                                    <hr>
                                    <ul class="uk-list uk-list-bullet in-list-check">
                                        <li>Instant Withdrawal</li>
                                        <li>Minimum Capital: <span class="in-highText">$500</span> </li>
                                        <li>Maximum Capital: <span class="in-highText">$3000</span> </li>
                                        <li>Duration: <span class="in-highText">24Hours.</span></li>
                                        <li>Profit: <span class="in-highText">20% ROI</span></li>
                                        <li>Plus: <span class="in-highText">10% Ultra token</span></li>
                                        <li>Referral Bonus: <span class="in-highText">8% of deposit </span></li>
                                    </ul>
                                    <a href="#" class="uk-button uk-button-primary uk-border-rounded uk-align-center">Invest on Premium Plan<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- section content end -->

        
        <!-- section content begin -->
        <div class="uk-section uk-section-secondary in-equity-8">
            <div class="uk-container uk-padding-remove uk-margin-medium-top uk-margin-medium-bottom">
                <div class="uk-grid uk-margin-remove uk-padding-remove-right uk-flex-center">
                    <div class="uk-width-1-1 uk-grid uk-text-center">
                        <div class="uk-width-1-1 uk-text-center">
                            <h1>Our Investment <span class="in-highlight">Statistics</span></h1>
                            <p class="uk-text-lead uk-margin-medium-bottom">Below are our current statistics on our most active deposit and withdrawal.</p>
                        </div>
                        <div class="uk-width-1-2@m  uk-card uk-card-body uk-border-rounded uk-box-shadow-large">
                            <div class="uk-overflow-auto">
                                <table class="uk-table">
                                    <thead>
                                        <tr>
                                            <th class="tableHead" colspan="3"> <span class="uk-text-large in-highlight">Our Latest Deposit</span> </th>
                                        </tr>
                                    </thead>
                                    <tbody class="tbody">
                                        <tr>
                                            <td><span class="in-icon icon-btc">BTC</span></td>
                                            <td>$3,500</td>
                                            <td>Bolbina Jesse</td>
                                        </tr>
                                        <tr>
                                            <td><span class="in-icon icon-eth">ETH</span></td>
                                            <td>$500</td>
                                            <td>Bolbina Jesse</td>
                                        </tr>
                                        <tr>
                                            <td><span class="in-icon icon-bnb">BNB</span></td>
                                            <td>Bolbina Jesse</td>
                                            <td>$35</td>
                                        </tr>
                                        <tr>
                                            <td><span class="in-icon icon-usdt">USDT</span></td>
                                            <td>$15</td>
                                            <td>Bolbina Jesse</td>
                                        </tr>
                                        <tr>
                                            <td><span class="in-icon icon-ultra">Ultra Token</span></td>
                                            <td>$25</td>
                                            <td>Bolbina Jesse</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="uk-width-1-1 uk-width-1-2@m uk-margin-large-top uk-margin-remove-top uk-card uk-card-body uk-border-rounded uk-box-shadow-large">
                            <div class="uk-overflow-auto">
                                <table class="uk-table">
                                    <thead>
                                        <tr>
                                            <th class="tableHead" colspan="4"> <span class="uk-text-large in-highlight">Our Latest Withdrawals</span> </th>
                                        </tr>
                                    </thead>
                                    <tbody class="tbody">
                                        <tr>
                                            <td><span class="in-icon icon-btc">BTC</span></td>
                                            <td>$3,500</td>
                                            <td>Bolbina Jesse</td>
                                        </tr>
                                        <tr>
                                            <td><span class="in-icon icon-eth">ETH</span></td>
                                            <td>$500</td>
                                            <td>Bolbina Jesse</td>
                                        </tr>
                                        <tr>
                                            <td><span class="in-icon icon-bnb">BNB</span></td>
                                            <td>Bolbina Jesse</td>
                                            <td>$35</td>
                                        </tr>
                                        <tr>
                                            <td><span class="in-icon icon-usdt">USDT</span></td>
                                            <td>$15</td>
                                            <td>Bolbina Jesse</td>
                                        </tr>
                                        <tr>
                                            <td><span class="in-icon icon-ultra">Ultra Token</span></td>
                                            <td>$25</td>
                                            <td>Bolbina Jesse</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section content end -->
        <!-- section content begin -->
        <div class="uk-section in-equity-9">
            <div class="uk-container uk-margin-medium-top uk-margin-bottom">
                
                <div class="uk-grid uk-flex uk-flex-center">
                    <div class="uk-width-3-4@m uk-margin-top">
                        <div class="uk-grid uk-child-width-1-3@s uk-child-width-1-3@m uk-text-center in-register" data-uk-grid>
                            <div class="uk-width-1-1 in-h-line">
                                <h2>Getting started is easy</h2>
                            </div>
                            <div>
                                <span class="in-icon-wrap circle">1</span>
                                <p>Choose an investment plan and register</p>
                            </div>
                            <div>
                                <span class="in-icon-wrap circle">2</span>
                                <p>Make payment to the specified address and wait for the duration period.</p>
                            </div>
                            <div>
                                <span class="in-icon-wrap circle">3</span>
                                <p>Withdraw your capital by applying from your dashboard using our automated blockchain payment system.</p>
                            </div>
                            <div class="uk-width-1-1">
                                <a href="./register.php" class="uk-button uk-button-text">create an account<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section content end -->
        <!-- section content begin -->
        <!-- <div class="uk-section in-equity-4">
            <div class="uk-container uk-margin-top uk-margin-medium-bottom">
                <div class="uk-grid uk-child-width-1-2@m in-testimonial-2" data-uk-grid>
                    <div class="uk-width-1-1@m uk-text-center">
                        <h1>More than <span class="in-highlight">23,000</span> traders joined</h1>
                    </div>
                    <div>
                        <div class="uk-background-contain uk-background-top-left" data-src="assets/img/in-equity-4-blob-1.svg" data-uk-img>
                            <div class="uk-flex uk-flex-middle">
                                <div class="uk-margin-right">
                                    <div class="uk-background-primary uk-border-pill">
                                        <img class="uk-align-center uk-border-pill" src="assets/img/in-lazy.gif" data-src="assets/img/blockit/in-team-1.png" alt="client-1" width="100" height="100" data-uk-img>
                                    </div>
                                </div>
                                <div>
                                    <h5 class="uk-margin-remove-bottom">Angela Nannenhorn</h5>
                                    <p class="uk-text-muted uk-margin-remove-top">from United Kingdom</p>
                                </div>
                            </div>
                            <blockquote>
                                <p>Very convenience for trader, spread for gold is relatively low compare to other broker</p>
                            </blockquote>
                        </div>
                    </div>
                    <div>
                        <div class="uk-background-contain uk-background-top-left" data-src="assets/img/in-equity-4-blob-2.svg" data-uk-img>
                            <div class="uk-flex uk-flex-middle">
                                <div class="uk-margin-right">
                                    <div class="uk-background-primary uk-border-pill">
                                        <img class="uk-align-center uk-border-pill" src="assets/img/in-lazy.gif" data-src="assets/img/blockit/in-team-8.png" alt="client-2" width="100" height="100" data-uk-img>
                                    </div>
                                </div>
                                <div>
                                    <h5 class="uk-margin-remove-bottom">Wade Palmer</h5>
                                    <p class="uk-text-muted uk-margin-remove-top">from Germany</p>
                                </div>
                            </div>
                            <blockquote>
                                <p>One of the best FX brokers, I have been using! their trading conditions are excellent</p>
                            </blockquote>
                        </div>
                    </div>
                    <div class="uk-width-1-1@m uk-text-center">
                        <a href="#" class="uk-button uk-button-text">See more traders stories from all over the world<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- section content end -->
        <!-- section content begin -->
        <div class="uk-section in-equity-5">
            <div class="uk-container uk-margin-remove-bottom">
                <div class="uk-grid uk-child-width-1-3@m uk-child-width-1-2@s" data-uk-grid>
                    <div>
                        <div class="uk-flex uk-flex-left in-award">
                            <div class="uk-margin-small-right">
                                <img src="assets/img/in-lazy.gif" data-src="assets/img/in-equity-5-award-1.svg" alt="award-1" width="91" height="82" data-uk-img>
                            </div>
                            <div>
                                <h6>Total Investors</h6>
                                <p class="provider">since consception</p>
                                <p class="year">219+</p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="uk-flex uk-flex-left in-award">
                            <div class="uk-margin-small-right">
                                <img src="assets/img/in-lazy.gif" data-src="assets/img/in-equity-7-icon-1.svg" alt="award-2" width="91" height="82" data-uk-img>
                            </div>
                            <div>
                                <h6>Total Deposits</h6>
                                <p class="provider">since consception</p>
                                <p class="year">$ 102,020</p>
                            </div>
                        </div>
                    </div>
                    <div class="uk-visible@m">
                        <div class="uk-flex uk-flex-left in-award">
                            <div class="uk-margin-small-right">
                                <img src="assets/img/in-lazy.gif" data-src="assets/img/in-equity-7-icon-1.svg" alt="award-3" width="91" height="82" data-uk-img>
                            </div>
                            <div>
                                <h6>Total Withdrawal</h6>
                                <p class="provider">since consception</p>
                                <p class="year">$ 152,021</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section content end -->
        <!-- section content begin -->
        <div class="uk-section uk-section-primary uk-preserve-color in-equity-6 uk-background-contain uk-background-center" data-src="assets/img/in-equity-14-bg.svg" data-uk-img>
            <div class="uk-container uk-margin-small-bottom">
                <div class="uk-grid uk-flex uk-flex-center">
                    <div class="uk-width-2xlarge@m uk-text-center">
                        <h1 style="color:#F4F0FD;">Ready to get started?</h1>
                        <p style="color:#F4F0FD;" class="uk-text-lead">Global access to exciting investment plan from a single account</p>
                    </div>
                    <div class="uk-width-3-4@m uk-margin-medium-top">
                        <div class="uk-flex uk-flex-center uk-flex-middle button-app">
                            <div>
                                <a href="./signin.html" class="uk-button uk-button-secondary uk-border-rounded">Start Investing now<i class="fas fa-arrow-circle-right uk-margin-small-left"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section content end -->
    </main>
    <?php require_once("./include/footer.inc.php"); ?>
    <!-- javascript -->
    <script src="assets/js/vendors/uikit.min.js"></script>
    <script src="assets/js/vendors/utilities.min.js"></script>
    <!-- <script src="assets/js/vendors/trading-widget.min.js"></script> -->
    <!-- <script src="assets/js/vendors/market-plugin.min.js"></script> -->
    <script src="assets/js/vendors/particles.min.js"></script>
    <script src="assets/js/config-particles.js"></script>
    <script src="assets/js/config-theme.js"></script>
</body>
</html>
