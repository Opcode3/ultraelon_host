<?php
    namespace app\config;

    interface DatabaseHandler{
        function connection();
    }

?>