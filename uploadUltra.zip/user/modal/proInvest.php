<div id="proInvestmentShow">
    <p>
        Thank you for deciding to be partners with us. We will appreciate it if you would use the below social media button links to connect with us.
        So as to enable us discuss the status of the partnership further. 
    </p>
    <p>
        We are so excitted to be going into partnership with you.
    </p>
    <p id="writtenBy">
        <b>President Ultra token</b>
        Nicolas Gilot
    </p>
    <div id="social_btn">
        <a href="http://" target="_blank" rel="noopener noreferrer">
            <img src="./assets/icons/instagram.png" alt="instagram icon">
            <span>Instagram</span>
        </a>
        <a href="http://" target="_blank" rel="noopener noreferrer">
            <img src="./assets/icons/whatsapp.svg" alt="whatsapp icon">
            <span>Whatsapp</span>
        </a>
        <a href="http://" target="_blank" rel="noopener noreferrer">
            <img src="./assets/icons/twitter.png" alt="instagram icon">
            <span>Twitter</span>
        </a>
    </div>
</div>
